"""
Test package for Enterprise Agentic Reliability Framework
"""